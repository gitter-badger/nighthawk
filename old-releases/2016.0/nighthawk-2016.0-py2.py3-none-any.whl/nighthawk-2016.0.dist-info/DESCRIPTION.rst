a powerful science and cryptography library


